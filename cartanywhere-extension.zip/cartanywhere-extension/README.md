# 🛒 CartAnywhere — Chrome Extension

**Save products from any website to your cart with one click.**

CartAnywhere adds a floating button to every page you visit. Click it to instantly save the current page — it will try to auto-detect the product name and price. View all your saved items from the extension popup.

---

## Installation

Since this is an unpacked extension, follow these steps:

1. **Unzip** the `cartanywhere-extension.zip` file
2. Open Chrome and go to `chrome://extensions/`
3. Enable **Developer mode** (toggle in the top-right corner)
4. Click **"Load unpacked"**
5. Select the unzipped `shopping-cart-extension` folder
6. Done! You should see the CartAnywhere icon in your toolbar

---

## How It Works

- **Floating Button**: An orange cart button appears on every page you visit. Click it to save the page.
- **Auto-Detection**: CartAnywhere tries to detect product names and prices from Amazon, Walmart, eBay, Target, Best Buy, and other major retailers.
- **Extension Popup**: Click the CartAnywhere icon in your toolbar to see all saved items, remove items, or open them all at once.
- **Badge Count**: The extension icon shows how many items are in your cart.

---

## Files Overview

| File | Purpose |
|------|---------|
| `manifest.json` | Chrome extension configuration |
| `popup.html/js` | The popup UI when you click the extension icon |
| `content.js` | Injected on every page — adds the floating button |
| `content.css` | Styles for the floating button and toast |
| `background.js` | Service worker for badge updates |
| `icons/` | Extension icons at 16, 48, and 128px |

---

## Customization

- Edit `content.css` to change the floating button position, colors, or size
- Add more price selectors in `content.js` → `priceSelectors` array for additional retailers
- Modify `popup.html` to change the popup theme

Enjoy quick shopping! 🎉
