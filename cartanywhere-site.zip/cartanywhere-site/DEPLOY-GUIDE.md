# Deploying CartAnywhere to GitHub Pages

## Step-by-Step Setup

### 1. Create a GitHub Account (skip if you have one)
- Go to [github.com](https://github.com) and sign up for a free account

### 2. Create a New Repository
- Click the **+** button in the top-right corner → **New repository**
- Name it: `cartanywhere` (or `cartanywhere.github.io` if you want it as your main site)
- Set it to **Public**
- Check **"Add a README file"**
- Click **Create repository**

### 3. Upload Your Site Files
- In your new repo, click **"Add file"** → **"Upload files"**
- Drag and drop ALL files from the `cartanywhere-site` folder:
  - `index.html` (your landing page)
  - `cartanywhere-extension.zip` (the extension download)
  - `icon.svg` (your logo)
- Write a commit message like "Initial site launch"
- Click **"Commit changes"**

### 4. Enable GitHub Pages
- Go to your repo's **Settings** tab
- In the left sidebar, click **Pages**
- Under **"Source"**, select **"Deploy from a branch"**
- Under **"Branch"**, select **main** and **/ (root)**
- Click **Save**
- Wait 1-2 minutes for it to deploy

### 5. Access Your Live Site
- Your site will be live at: `https://YOUR-USERNAME.github.io/cartanywhere/`
- (Or `https://YOUR-USERNAME.github.io/` if you named the repo `YOUR-USERNAME.github.io`)

---

## After Deployment: Update the Extension

Once your site is live, you need to update the extension to point to your real URL.

Open these 3 files in the extension folder and replace `https://cartanywhere.app` with your actual GitHub Pages URL:

| File | Line to change |
|------|---------------|
| `popup.js` | `const CARTANYWHERE_APP_URL = 'https://YOUR-USERNAME.github.io/cartanywhere/';` |
| `content.js` | `const CARTANYWHERE_APP_URL = 'https://YOUR-USERNAME.github.io/cartanywhere/';` |
| `background.js` | `const CARTANYWHERE_APP_URL = 'https://YOUR-USERNAME.github.io/cartanywhere/';` |

Then re-zip the extension folder and replace the `cartanywhere-extension.zip` in your GitHub repo.

---

## Optional: Custom Domain

If you buy a custom domain (like `cartanywhere.app`):

1. Go to your repo **Settings** → **Pages**
2. Under **"Custom domain"**, enter your domain
3. Add these DNS records at your domain registrar:
   - Type: **A** → `185.199.108.153`
   - Type: **A** → `185.199.109.153`
   - Type: **A** → `185.199.110.153`
   - Type: **A** → `185.199.111.153`
   - Type: **CNAME** → `YOUR-USERNAME.github.io`
4. Check **"Enforce HTTPS"**

---

## Updating Your Site

To make changes:
1. Edit files locally
2. Go to your GitHub repo
3. Click **"Add file"** → **"Upload files"**
4. Upload the updated files (they'll overwrite the old ones)
5. Commit — changes go live in ~1 minute
